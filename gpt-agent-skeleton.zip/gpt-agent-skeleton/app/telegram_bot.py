import os
import asyncio
from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, filters, ContextTypes
from app.agent import chat_with_tools

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")

async def on_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message:
        return
    text = update.message.text or ""
    reply, _, _ = chat_with_tools(text)
    await update.message.reply_text(reply)

async def main():
    if not TOKEN:
        print("TELEGRAM_BOT_TOKEN is not set")
        return
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_message))
    await app.initialize()
    await app.start()
    print("Bot started. Press Ctrl+C to stop.")
    await app.updater.start_polling()
    await app.updater.idle()

if __name__ == "__main__":
    asyncio.run(main())
