from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
from .schemas import ChatRequest, ChatResponse
from .agent import chat_with_tools
from .logging_conf import setup_logging

log = setup_logging()

app = FastAPI(title="GPT Agent")

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    try:
        reply, tool_execs, raw = chat_with_tools(req.text)
        return ChatResponse(reply=reply, tool_calls=tool_execs, raw=None)
    except Exception as e:
        log.exception("Chat error")
        raise HTTPException(status_code=500, detail=str(e))

# ----- Telegram webhook (опционально) -----
@app.post("/telegram/webhook")
async def telegram_webhook(request: Request):
    data = await request.json()
    try:
        message = data.get("message", {}) or data.get("edited_message", {})
        chat_id = message.get("chat", {}).get("id")
        text = message.get("text", "")
        if chat_id and text:
            reply, _, _ = chat_with_tools(text)
            # Отправка ответа пользователю
            import os, httpx
            token = os.getenv("TELEGRAM_BOT_TOKEN", "")
            if token:
                async with httpx.AsyncClient() as client:
                    await client.post(f"https://api.telegram.org/bot{token}/sendMessage",
                                      json={"chat_id": chat_id, "text": reply})
    except Exception as e:
        log.exception("Telegram webhook error")
    return JSONResponse({"ok": True})
