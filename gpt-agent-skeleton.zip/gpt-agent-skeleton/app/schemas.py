from pydantic import BaseModel, Field
from typing import Optional, Literal, List, Any

class ChatRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=4000)
    user_id: Optional[str] = None
    session_id: Optional[str] = None

class ToolCall(BaseModel):
    name: str
    arguments: dict

class ChatResponse(BaseModel):
    reply: str
    tool_calls: Optional[List[ToolCall]] = None
    raw: Optional[Any] = None
