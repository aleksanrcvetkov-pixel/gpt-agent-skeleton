from typing import List, Tuple, Dict, Any, Optional
from openai import OpenAI
from .config import OPENAI_API_KEY, OPENAI_MODEL
from .tools import get_tools_spec, dispatch_tool

client = OpenAI(api_key=OPENAI_API_KEY)

SYSTEM_PROMPT = (
    "Ты — агент для Александра (психолог и создатель контента). "
    "Твоя задача: генерировать короткие и структурированные ответы, "
    "предлагать контент-планы, сценарии рилс/каруселей, "
    "и вызывать инструменты при необходимости (создание лида, план контента). "
    "Тон профессиональный, без вопросов в конце."
)

def chat_with_tools(user_text: str, thread_state: Optional[List[Dict[str, str]]] = None) -> Tuple[str, List[Dict[str, Any]], Dict[str, Any]]:
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    if thread_state:
        messages.extend(thread_state)
    messages.append({"role": "user", "content": user_text})

    completion = client.chat.completions.create(
        model=OPENAI_MODEL,
        messages=messages,
        tools=get_tools_spec(),
        tool_choice="auto",
        temperature=0.5,
    )

    message = completion.choices[0].message
    tool_calls = message.tool_calls or []

    executed = []
    if tool_calls:
        for call in tool_calls:
            fn_name = call.function.name
            args = call.function.arguments
            import json
            try:
                parsed = json.loads(args) if isinstance(args, str) else args
            except Exception:
                parsed = {}
            result = dispatch_tool(fn_name, parsed or {})
            executed.append({"name": fn_name, "arguments": parsed, "result": result})

        # отправляем результаты обратно в модель (второй проход)
        messages.append({"role": "assistant", "content": message.content or "", "tool_calls": [
            {"id": c.id, "type": "function", "function": {"name": c.function.name, "arguments": c.function.arguments}}
            for c in tool_calls
        ]})
        for e in executed:
            messages.append({"role": "tool", "tool_call_id": tool_calls[0].id, "name": e["name"], "content": str(e["result"])})

        final = client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=messages,
            temperature=0.5,
        )
        reply = final.choices[0].message.content or ""
        return reply, executed, {"first": completion, "second": final}

    reply = message.content or ""
    return reply, executed, {"first": completion}
