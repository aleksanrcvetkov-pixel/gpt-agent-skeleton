import json
from typing import Dict, Any, List, Tuple, Optional
import os

from .config import GOOGLE_SERVICE_ACCOUNT_JSON, GOOGLE_SERVICE_ACCOUNT_FILE, GOOGLE_SHEET_NAME

# ----- Google Sheets (create_lead) -----
def _get_gspread_client():
    import gspread
    from google.oauth2.service_account import Credentials

    if GOOGLE_SERVICE_ACCOUNT_JSON:
        info = json.loads(GOOGLE_SERVICE_ACCOUNT_JSON)
        creds = Credentials.from_service_account_info(info, scopes=[
            "https://www.googleapis.com/auth/spreadsheets",
            "https://www.googleapis.com/auth/drive"
        ])
    elif GOOGLE_SERVICE_ACCOUNT_FILE and os.path.exists(GOOGLE_SERVICE_ACCOUNT_FILE):
        creds = Credentials.from_service_account_file(GOOGLE_SERVICE_ACCOUNT_FILE, scopes=[
            "https://www.googleapis.com/auth/spreadsheets",
            "https://www.googleapis.com/auth/drive"
        ])
    else:
        raise RuntimeError("Google service account credentials not configured")

    return gspread.authorize(creds)

def create_lead(name: str, contact: str, source: str, notes: str = "") -> Dict[str, Any]:
    gc = _get_gspread_client()
    sh = gc.create(GOOGLE_SHEET_NAME) if GOOGLE_SHEET_NAME not in [s.title for s in gc.openall()] else gc.open(GOOGLE_SHEET_NAME)
    try:
        ws = sh.worksheet("Leads")
    except Exception:
        ws = sh.add_worksheet(title="Leads", rows=1000, cols=10)
        ws.append_row(["timestamp", "name", "contact", "source", "notes"])

    from datetime import datetime
    ts = datetime.utcnow().isoformat()
    ws.append_row([ts, name, contact, source, notes])
    return {"ok": True, "timestamp": ts, "sheet": sh.title, "worksheet": ws.title}

# ----- plan_content (локальная функция) -----
def plan_content(days: int, platform: str, tone: Optional[str] = None) -> Dict[str, Any]:
    days = max(1, min(days, 30))
    items = []
    for i in range(days):
        items.append({
            "day": i + 1,
            "type": "reel" if i % 2 == 0 else "carousel",
            "hook": "Сохрани это, чтобы не потерять",
            "points": ["Шаг 1", "Шаг 2", "Шаг 3"],
            "cta": "Подпишитесь, чтобы не пропустить новые разборы"
        })
    return {"platform": platform, "tone": tone or "professional", "plan": items}

# ----- Список инструментов для OpenAI -----
def get_tools_spec() -> List[dict]:
    return [
        {
            "type": "function",
            "function": {
                "name": "create_lead",
                "description": "Добавить лида в Google Sheets",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "contact": {"type": "string"},
                        "source": {"type": "string", "enum": ["instagram","tiktok","site","direct"]},
                        "notes": {"type": "string"}
                    },
                    "required": ["name","contact","source"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "plan_content",
                "description": "Сформировать контент-план на N дней",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "days": {"type": "integer","minimum": 1,"maximum": 30},
                        "platform": {"type": "string","enum": ["instagram","tiktok"]},
                        "tone": {"type": "string"}
                    },
                    "required": ["days","platform"]
                }
            }
        }
    ]

# Диспетчер выполнения функций
def dispatch_tool(name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
    if name == "create_lead":
        return create_lead(**arguments)
    if name == "plan_content":
        return plan_content(**arguments)
    raise ValueError(f"Unknown tool: {name}")
